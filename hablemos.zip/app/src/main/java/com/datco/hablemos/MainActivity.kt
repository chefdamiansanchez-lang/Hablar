package com.datco.hablemos

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Fondo = Color(0xFF0A1A3F)
val Suave = Color(0xFF8FA6D6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Raiz()
            }
        }
    }
}

@Composable
fun Raiz() {
    var splash by remember { mutableStateOf(true) }
    if (splash) Splash { splash = false } else Principal()
}

/* ---------- Splash DATCO con zoom ---------- */
@Composable
fun Splash(onFin: () -> Unit) {
    val escala = remember { Animatable(0.6f) }
    val alfa = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { alfa.animateTo(1f, tween(700)) }
        launch { escala.animateTo(1.15f, tween(2200, easing = FastOutSlowInEasing)) }
        delay(2400)
        onFin()
    }
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF1B2028)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                scaleX = escala.value
                scaleY = escala.value
                this.alpha = alfa.value
            }
        ) {
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) {
                Text("D", color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "DATCO",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 10.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías\ny Códigos Operativos",
                color = Color(0xFF9AA5B5),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = Color(0xFF9AA5B5),
            fontSize = 13.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp)
        )
    }
}

/* ---------- Reconocimiento de voz continuo ---------- */
class Escucha(
    private val ctx: Context,
    private val onParcial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onEstado: (Boolean) -> Unit
) {
    private var sr: SpeechRecognizer? = null
    private var activo = false
    private val h = Handler(Looper.getMainLooper())

    fun iniciar() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Toast.makeText(ctx, "Este teléfono no tiene reconocimiento de voz", Toast.LENGTH_LONG).show()
            return
        }
        activo = true
        onEstado(true)
        escuchar()
    }

    private fun escuchar() {
        if (!activo) return
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p0: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p0: Float) {}
            override fun onBufferReceived(p0: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(p0: Int, p1: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onParcial(t)
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                onParcial("")
                if (!t.isNullOrBlank()) onFinal(t)
                reiniciar()
            }
            override fun onError(e: Int) {
                onParcial("")
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    detener()
                    return
                }
                reiniciar()
            }
        })
        sr = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        r.startListening(i)
    }

    private fun reiniciar() {
        if (activo) h.postDelayed({ escuchar() }, 300)
    }

    fun detener() {
        activo = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        sr = null
        onEstado(false)
        onParcial("")
    }
}

/* ---------- Pantalla principal ---------- */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun Principal() {
    val ctx = LocalContext.current
    val mensajes = remember { mutableStateListOf<String>() }
    var parcial by remember { mutableStateOf("") }
    var escuchando by remember { mutableStateOf(false) }
    var teclado by remember { mutableStateOf(false) }
    var texto by remember { mutableStateOf("") }
    val foco = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current
    val lista = rememberLazyListState()
    LocalView.current.keepScreenOn = true

    val escucha = remember {
        Escucha(ctx, { parcial = it }, { mensajes.add(it) }, { escuchando = it })
    }
    DisposableEffect(Unit) { onDispose { escucha.detener() } }

    val permiso = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            teclado = false
            escucha.iniciar()
        }
    }

    fun alternarMic() {
        if (escuchando) {
            escucha.detener()
        } else {
            teclado = false
            kb?.hide()
            val concedido = ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (concedido) escucha.iniciar() else permiso.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun enviar() {
        if (texto.isNotBlank()) mensajes.add(texto.trim())
        texto = ""
        teclado = false
        kb?.hide()
    }

    val items = if (parcial.isNotBlank()) mensajes.toList() + parcial else mensajes.toList()

    LaunchedEffect(items.size, parcial) {
        if (items.isNotEmpty()) lista.animateScrollToItem(items.lastIndex)
    }
    LaunchedEffect(teclado) {
        if (teclado) {
            foco.requestFocus()
            kb?.show()
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Fondo)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Hablemos", color = Suave, fontSize = 16.sp)
            TextButton(onClick = {
                mensajes.clear()
                parcial = ""
            }) { Text("Borrar", color = Suave, fontSize = 16.sp) }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (items.isEmpty()) {
                Text(
                    "Tocá 🎤 para hablar\no ⌨️ para escribir",
                    color = Suave,
                    fontSize = 26.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    state = lista,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)
                ) {
                    itemsIndexed(items) { i, m ->
                        val ultimo = i == items.lastIndex
                        Text(
                            m,
                            color = Color.White,
                            fontSize = if (ultimo) 44.sp else 28.sp,
                            lineHeight = if (ultimo) 52.sp else 34.sp,
                            fontWeight = if (ultimo) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp)
                                .alpha(if (ultimo) 1f else 0.65f)
                        )
                    }
                }
            }
        }

        if (teclado) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = texto,
                    onValueChange = { texto = it },
                    modifier = Modifier.weight(1f).focusRequester(foco),
                    textStyle = TextStyle(fontSize = 22.sp, color = Color.White),
                    placeholder = { Text("Escribí acá…", color = Suave, fontSize = 20.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color.White,
                        focusedBorderColor = Color.White,
                        unfocusedBorderColor = Suave
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { enviar() })
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { enviar() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    modifier = Modifier.height(56.dp)
                ) { Text("➤", fontSize = 22.sp, color = Color.White) }
                Spacer(Modifier.width(6.dp))
                Button(
                    onClick = {
                        teclado = false
                        kb?.hide()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B4C9B)),
                    modifier = Modifier.height(56.dp)
                ) { Text("✕", fontSize = 22.sp, color = Color.White) }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        if (escuchando) escucha.detener()
                        teclado = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B4C9B)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.weight(1f).height(72.dp)
                ) { Text("⌨️  Escribir", fontSize = 22.sp, color = Color.White) }
                Button(
                    onClick = { alternarMic() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (escuchando) Color(0xFFC62828) else Color(0xFF2E7D32)
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.weight(1f).height(72.dp)
                ) {
                    Text(
                        if (escuchando) "⏹  Parar" else "🎤  Hablar",
                        fontSize = 22.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}
